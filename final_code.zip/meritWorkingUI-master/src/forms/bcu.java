package forms;

import java.awt.Color;
import javax.swing.*;
import java.awt.Font;
import java.awt.event.*;

public class bcu extends JFrame implements ActionListener {
  JLabel l1, l2, l3, l4, l5, l6, l7, l8, l9, l10, l11, l12, l13, l14, l15, l16, l17, l18;
  JTextField t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t15;
  JButton b1;
  Font f;

  public bcu(String title) {
    super(title);
    f = new Font("Arial", Font.BOLD, 16);
    l1 = new JLabel("C.S.E");
    l2 = new JLabel("I.T");
    l3 = new JLabel("E.C.E");
    l4 = new JLabel("E.E.E");
    l5 = new JLabel("M.A.E");

    l16 = new JLabel("GENERAL");
    l16.setForeground(Color.blue);
    l16.setFont(f);

    t1 = new JTextField();
    t2 = new JTextField();
    t3 = new JTextField();
    t4 = new JTextField();
    t5 = new JTextField();

    b1 = new JButton("Set Cutoff");
    setLayout(null);
    l16.setBounds(160, 5, 500, 100);
    add(l16);

    l1.setBounds(50, 40, 500, 100);
    t1.setBounds(150, 80, 100, 25);

    add(l1);
    add(t1);

    l2.setBounds(50, 140, 500, 100);
    t2.setBounds(150, 180, 100, 25);

    add(l2);
    add(t2);

    l3.setBounds(50, 240, 500, 100);
    t3.setBounds(150, 280, 100, 25);

    add(l3);
    add(t3);

    l4.setBounds(50, 340, 500, 100);
    t4.setBounds(150, 380, 100, 25);

    add(l4);
    add(t4);

    l5.setBounds(50, 440, 500, 100);
    t5.setBounds(150, 480, 100, 25);

    add(l5);
    add(t5);

    b1.setBounds(450, 570, 100, 30);
    add(b1);
    b1.addActionListener(this);
  }

  @Override
  public void actionPerformed(ActionEvent ae) {
    if (ae.getSource() == b1) {
      Calculation cs = new Calculation();
      cs.gcse = Float.parseFloat(t1.getText());
      cs.git = Float.parseFloat(t2.getText());
      cs.gece = Float.parseFloat(t3.getText());
      cs.geee = Float.parseFloat(t4.getText());
      cs.gma = Float.parseFloat(t5.getText());

      JOptionPane.showMessageDialog(null, "the cutoff has been set");
      dispose();
    }
  }

  public static void main(String[] args) {
    bcu b = new bcu("BTech Cutoff Update");
    b.setSize(1000, 650);
    b.setLocation(50, 50);
    b.setDefaultCloseOperation(EXIT_ON_CLOSE);
    b.setResizable(false);
    b.setVisible(true);
  }
}