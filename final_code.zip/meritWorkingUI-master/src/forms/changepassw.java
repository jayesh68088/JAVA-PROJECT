package forms;

import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
import java.awt.Color;

public class changepassw extends JFrame implements ActionListener {
  private Connection con;
  private PreparedStatement ps, ps1;
  private ResultSet rs;
  JLabel l1, l2, l3, bgLabel;
  JPasswordField p1, p2;
  JButton b1, b2;
  JTextField t1;

  public changepassw(String title) {
    super(title);
    l1 = new JLabel("Old Password");
    l2 = new JLabel("New Password");
    l3 = new JLabel("Username");
    t1 = new JTextField();
    p1 = new JPasswordField();
    p2 = new JPasswordField();
    b1 = new JButton("Submit");
    b2 = new JButton("Cancel");
    setLayout(null);
    l3.setBounds(500, 140, 120, 30);
    l1.setBounds(500, 180, 120, 30);
    l2.setBounds(500, 220, 120, 30);
    t1.setBounds(620, 140, 150, 30);
    p1.setBounds(620, 180, 150, 30);
    p2.setBounds(620, 220, 150, 30);
    b1.setBounds(640, 280, 100, 30);
    b2.setBounds(530, 280, 100, 30);

    Color customRed = new Color(255, 96, 92);
    Color customGreen = new Color(0, 202, 78);

    b1.setBackground(customGreen);
    b2.setBackground(customRed);

    add(l1);
    add(l2);
    add(p1);
    add(p2);
    add(b1);
    add(b2);
    add(l3);
    add(t1);

    bgLabel = new JLabel(new ImageIcon("changePassbg.png"));
    bgLabel.setBounds(0, -30, 900, 600);
    add(bgLabel);

    b1.addActionListener(this);
    b2.addActionListener(this);
  }

  boolean result;

  public void actionPerformed(ActionEvent ae) {
    if (ae.getSource() == b2) {
      dispose();
    }
    if (ae.getSource() == b1) {
      try {

        Database db = new Database();
        con = db.connect();

        ps = con.prepareStatement("select * from log where username=? and passwd=?");
        ps.setString(1, t1.getText());
        ps.setString(2, p1.getText());
        ResultSet rs = ps.executeQuery();
        rs.next();
        String s = rs.getString("username");
        String s1 = rs.getString("passwd");
        ps1 = con.prepareStatement("update log set passwd=? where username=? and passwd=?");
        ps1.setString(1, p2.getText());
        ps1.setString(2, s);
        ps1.setString(3, s1);
        ps1.executeUpdate();
        JOptionPane.showMessageDialog(null, "password changed");
        t1.setText("");
        p1.setText("");
        p2.setText("");
        dispose();
      } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "No Such Record Found " + e);
      }
    }
  }

  public static void main(String[] args) {
    changepassw obj = new changepassw("Change Password");
    obj.setSize(900, 600);
    obj.setLocation(450, 150);
    obj.setDefaultCloseOperation(EXIT_ON_CLOSE);
    obj.setResizable(false);
    obj.setVisible(true);
  }

}
