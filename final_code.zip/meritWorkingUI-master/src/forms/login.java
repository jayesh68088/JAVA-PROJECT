package forms;

import java.awt.Color;
import javax.swing.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class login extends JFrame implements ActionListener {

  private Connection con;
  private PreparedStatement ps, ps1;
  private ResultSet rs, rs1;
  JButton b1, b2;
  JLabel l1, l2, bgLabel;
  JTextField t1;
  JPasswordField p1;

  public login(String title) {
    super(title);
    b1 = new JButton("Login");
    b2 = new JButton("Cancel");
    l1 = new JLabel("Login Id");
    l2 = new JLabel("Password");
    t1 = new JTextField();
    p1 = new JPasswordField();
    setLayout(null);
    l1.setBounds(540, 180, 100, 30);
    l2.setBounds(540, 230, 100, 30);
    t1.setBounds(640, 180, 150, 30);
    p1.setBounds(640, 230, 150, 30);
    add(l1);
    add(l2);
    add(t1);
    add(p1);
    b1.setBounds(570, 290, 100, 30);
    b2.setBounds(690, 290, 100, 30);

    Color customRed = new Color(255, 96, 92);
    Color customGreen = new Color(0, 202, 78);
    b1.setBackground(customGreen);
    b2.setBackground(customRed);
    b2.setForeground(Color.WHITE);
    b1.setForeground(Color.WHITE);

    add(b1);
    add(b2);
    b1.addActionListener(this);
    b2.addActionListener(this);

    bgLabel = new JLabel(new ImageIcon("LoginPagebg.png"));
    bgLabel.setBounds(0, 0, 900, 600);
    add(bgLabel);
  }

  @Override
  public void actionPerformed(ActionEvent ae) {
    if (ae.getSource() == b2) {
      dispose();
    }
    if (ae.getSource() == b1) {
      try {
        Database db = new Database();
        con = db.connect();
        if (!(t1.getText()).equals("") && !(p1.getText()).equals("")) {
          ps = con.prepareStatement("select * from log where username=? and passwd=? ");
          ps.setString(1, t1.getText());
          ps.setString(2, p1.getText());
          rs = ps.executeQuery();
          rs.next();
          ps1 = con.prepareStatement("select mob from log where username=?");
          ps1.setString(1, t1.getText());
          rs1 = ps1.executeQuery();
          rs1.next();
          String pno = rs1.getString("mob");
          dispose();
          studentpan stp = new studentpan("Student Panel", pno);
          stp.setSize(900, 600);
          stp.setLocation(350, 125);
          stp.setVisible(true);
          stp.setResizable(false);
          stp.getContentPane();
        } else {
          JOptionPane.showMessageDialog(null, "Name or Password Cannot be Blank\nLogin Unsuccessful,Try again");
        }
      } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Sorry No Such Record :  " + e);
      }
    }
  }

  public static void main(String[] args) {
    login log = new login("Log In");
    log.setSize(900, 600);
    log.setLocation(450, 150);
    log.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    log.setResizable(false);
    log.setVisible(true);
  }
}
