package forms;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.*;
import javax.swing.*;

public class MainWindow extends JFrame implements ActionListener, MouseListener {

    JMenuBar mb;
    JMenu nMain, nPlac, nFeeStruct, nSeat, nFaculty, nCon;
    JMenuItem fExit, fB, fM, fplp, fplc, finst, fadmi, fSpace;
    JLabel l1, l2, l3, l4, l10, bgLabel, l12, l13;
    Font f, f1, f2;
    JButton b2, b3;

    public MainWindow() {

        bgLabel = new JLabel(new ImageIcon("homePagebg.png"));

        mb = new JMenuBar();
        fadmi = new JMenu("Admin Login");
        nFeeStruct = new JMenu("Fee Structure");
        nSeat = new JMenu("Seat Matrix");
        finst = new JMenu("Instructions");
        fSpace = new JMenu(
                "                                                                                                                ");
        fExit = new JMenu("Exit");

        b2 = new JButton("Log in");
        b3 = new JButton("Register");
        mb.add(fadmi);
        mb.add(nFeeStruct);
        mb.add(nSeat);
        mb.add(finst);
        mb.add(fSpace);
        mb.add(fExit);

        f = new Font("Constantia", Font.BOLD, 45);
        f1 = new Font("Arial", Font.BOLD, 14);
        f2 = new Font("Algerian", Font.BOLD, 20);

        setLayout(null);
        bgLabel.setBounds(0, 50, 900,600);

        b2.setBounds(350, 280, 100, 40);
        b3.setBounds(470, 280, 100, 40);
        Color customColor = new Color(175, 12, 62);
        b2.setBackground(customColor);
        b3.setBackground(customColor);
        b2.setForeground(Color.white);
        b3.setForeground(Color.white);
        add(b2);
        add(b3);

        mb.setBounds(0, 0, 1000, 50);
        mb.setBackground(Color.white);
        mb.setForeground(Color.black);
        fExit.setForeground(Color.red);
        add(bgLabel);
        add(mb);

        b2.addActionListener(this);
        b3.addActionListener(this);

        nFeeStruct.addMouseListener(this);
        nSeat.addMouseListener(this);
        fExit.addMouseListener(this);
        finst.addMouseListener(this);
        fadmi.addMouseListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b3) {
            Register reg = new Register("Registration");
            reg.setSize(900, 600);
            reg.setLocation(550, 225);
            reg.setVisible(true);
        }
        if (ae.getSource() == b2) {
            login log = new login("Log_In");
            log.setSize(900, 600);
            log.setLocation(550, 225);
            log.setResizable(false);
            log.setVisible(true);
        }
    }

    @Override
    public void mouseClicked(MouseEvent me) {
        if (me.getSource() == nFeeStruct) {
            Fee obj = new Fee("Fee Structure");
            obj.setSize(700, 550);
            obj.setLocation(350, 100);
            obj.setVisible(true);
        }
        if (me.getSource() == nSeat) {
            SeatMatrixB smb = new SeatMatrixB("SeatMatrix");
            smb.setSize(710, 300);
            smb.setLocation(250, 150);
            smb.setVisible(true);
        }
    }

    @Override
    public void mousePressed(MouseEvent me) {
        if (me.getSource() == fExit)
            System.exit(0);
        if (me.getSource() == finst) {
            steps s = new steps("Instructions To Follow");
            s.setSize(900, 600);
            s.setLocation(400, 200);
            s.setVisible(true);
        }
        if (me.getSource() == fadmi) {
            admlogin logi = new admlogin("Admin Panel");
            logi.setSize(900, 600);
            logi.setLocation(550, 225);
            logi.setVisible(true);
            logi.setDefaultCloseOperation(EXIT_ON_CLOSE);
            logi.setResizable(false);
            logi.getContentPane().setBackground(Color.white);
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    public static void main(String[] args) {
        MainWindow obj = new MainWindow();
        obj.getContentPane().setBackground(Color.black);
        obj.setSize(900, 600);
        obj.setLocation(550, 225);
        obj.setTitle("Amrita University, Amritapuri Admission Portal");
        obj.setDefaultCloseOperation(EXIT_ON_CLOSE);
        obj.setResizable(false);
        obj.setVisible(true);
    }
}