package forms;

import javax.swing.*;

import java.awt.Color;
import java.awt.event.*;
import java.sql.*;

public class Register extends JFrame implements ActionListener {
    JLabel l1, l2, l3, l4, bgLabel;
    JTextField t1, t2;
    JPasswordField p1;
    JButton b1, b2;
    private Connection con;
    private PreparedStatement ps;

    public Register(String title) {
        super(title);
        l2 = new JLabel("Name");
        l3 = new JLabel("Password");
        l4 = new JLabel("Mobile");
        b1 = new JButton("Submit");
        b2 = new JButton("Cancel");
        t1 = new JTextField();
        t2 = new JTextField();
        p1 = new JPasswordField();
        setLayout(null);
        l2.setBounds(530, 150, 100, 30);
        t1.setBounds(650, 150, 150, 30);
        add(l2);
        add(t1);
        l3.setBounds(530, 180, 100, 30);
        bgLabel = new JLabel(new ImageIcon("RegisterPagebg.png"));
        bgLabel.setBounds(-45, 0, 1000, 605);
        p1.setBounds(650, 180, 150, 30);
        l4.setBounds(530, 210, 100, 30);
        t2.setBounds(650, 210, 150, 30);
        add(l3);
        add(p1);
        add(l4);
        add(t2);
        b1.setBounds(570, 290, 100, 30);
        b2.setBounds(690, 290, 100, 30);
        Color customRed = new Color(255, 96, 92);
        Color customGreen = new Color(0, 202, 78);
        b1.setBackground(customGreen);
        b2.setBackground(customRed);
        b2.setForeground(Color.WHITE);
        b1.setForeground(Color.WHITE);
        b1.addActionListener(this);
        b2.addActionListener(this);
        add(b1);
        add(b2);
        add(bgLabel);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b2) {
            dispose();
        }
        if (ae.getSource() == b1) {
            String s1 = t1.getText(), s2 = t2.getText();
            char[] c1 = s1.toCharArray();
            char[] c2 = s2.toCharArray();

            try {
                Database db = new Database();
                con = db.connect();
                ps = con.prepareStatement("insert into log values(?,?,?)");
                if (!(p1.getText()).equals("") && !(t2.getText()).equals("") && !s1.equals("")) {
                    ps.setString(1, s1);
                    ps.setString(2, p1.getText());
                    ps.setString(3, t2.getText());
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null,
                            "Registration Successful,Use your Username and password to login");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Name or Password Cannot be Blank\nRegistration Unsuccessful,Try again");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Something Went Wrong :  " + e);
            }
        }
    }

    public static void main(String[] args) {
        Register reg = new Register("Registration");
        reg.setSize(900, 600);
        reg.setLocation(420, 240);
        reg.setDefaultCloseOperation(EXIT_ON_CLOSE);
        reg.setVisible(true);
        reg.setResizable(false);
    }
}
